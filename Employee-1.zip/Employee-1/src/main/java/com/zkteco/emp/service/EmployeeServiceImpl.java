package com.zkteco.emp.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import com.zkteco.emp.dto.DTO;
import com.zkteco.emp.dto.ResultDTO;
import com.zkteco.emp.entity.Employee;
import com.zkteco.emp.error.EmployeeNotFoundException;
import com.zkteco.emp.repository.EmployeeRepository;

@Component
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeRepository empRepository;
	@Autowired
	EmployeeService empService;
		
	
	public ResultDTO entityToDto(Employee emp) {
		ResultDTO dto = new ResultDTO();
		dto.setId(emp.getEmpId());
		dto.setFirstName(emp.getFirstName());
		dto.setLastName(emp.getLastName());
		dto.setEmpCode(emp.getEmpcode());
		dto.setEmailId(emp.getEmailId());
		dto.setDesignation(emp.getDesignation());
		dto.setDob(emp.getDob());
		dto.setMobile(emp.getMobile());
		
		return dto;
		
	}
	
	public List<ResultDTO> entityToDto(List<Employee> emp) {
			
		return emp.stream().map(x -> entityToDto(x)).collect(Collectors.toList());

	}
	
	public Employee dtoToEntity(ResultDTO dto) {
		Employee emp = new Employee();
		emp.setEmpId(dto.getId());
		emp.setFirstName(dto.getFirstName());
		emp.setLastName(dto.getLastName());
		emp.setEmpcode(dto.getEmpCode());
		emp.setEmailId(dto.getEmailId());
		emp.setDesignation(dto.getDesignation());
		emp.setDob(dto.getDob());
		emp.setMobile(dto.getMobile());
		return emp;
		
	}
	
	public List<Employee> dtoToEntity(List<ResultDTO> dto) {
		
		return dto.stream().map(x -> dtoToEntity(x)).collect(Collectors.toList());
		
	}

	public Employee updateDepartmentById(Long id, Employee emp) {
		Employee emp1=empRepository.findById(id).get();
		if(Objects.nonNull(emp.getFirstName()) &&
				!"".equalsIgnoreCase(emp.getFirstName())){
			emp1.setFirstName(emp.getFirstName());
		}
		if(Objects.nonNull(emp.getLastName()) &&
				!"".equalsIgnoreCase(emp.getLastName())){
			emp1.setLastName(emp.getLastName());
		}
		if(Objects.nonNull(emp.getEmpcode()) &&
				!"".equalsIgnoreCase(emp.getEmpcode())){
			emp1.setEmpcode(emp.getEmpcode());
		}
		if(Objects.nonNull(emp.getDesignation()) &&
				!"".equalsIgnoreCase(emp.getDesignation())){
			emp1.setDesignation(emp.getDesignation());
		}
		if(Objects.nonNull(emp.getEmailId()) &&
				!"".equalsIgnoreCase(emp.getEmailId())){
			emp1.setEmailId(emp.getEmailId());
		}
		if(Objects.nonNull(emp.getDob()) &&
				!"".equalsIgnoreCase(emp.getDob())){
			emp1.setDob(emp.getDob());
		}
		if(Objects.nonNull(emp.getMobile()) &&
				!"".equalsIgnoreCase(emp.getMobile())){
			emp1.setMobile(emp.getMobile());
		}
		
		
		return empRepository.save(emp1);
	
	}

	@Override
	public Employee deleteEmployeeById(Long id) throws EmployeeNotFoundException {
		Employee emp = empRepository.deleteEmployeeById(id);
		return emp;
	}
	@Override
	public Page<Employee> findPaginated(int pageNo, int pageSize) {
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize);
		return this.empRepository.findAll(pageable);
	}

	@Override
	public ResponseEntity<Map<String,Object>> getAllEmployee(String search, int page, int size, String[] sort) {
		try {
			List<Order> orders = new ArrayList<Order>();
			if(sort[0].contains(",")) {
				for(String sortOrder : sort) {
					String[] sortA = sortOrder.split(",");
					orders.add(new Order(getSortDirection(sortA[1]), sortA[0]));
				}
			}
				else {
					orders.add(new Order(getSortDirection(sort[1]), sort[0]));
				}
			Pageable paging =PageRequest.of(page, size,Sort.by(orders));
			
			Page<Employee> pageTuts;
			if(search == null) {
				pageTuts = empRepository.findAll(paging);
			}else {
				pageTuts = empRepository.employeeContaining(search , paging);
			}
			List<Employee> emp = pageTuts.getContent();
			
			Map<String , Object> res = new HashMap<>();
			res.put("employee", emp);
			res.put("currentPage", pageTuts.getNumber());
			res.put("totalItems", pageTuts.getTotalElements());
			res.put("totalPages", pageTuts.getTotalPages());
			
			return new ResponseEntity<>(res,HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private Sort.Direction getSortDirection(String direction) {
		if(direction.equals("asc")) {
			return Sort.Direction.ASC;
		}else if(direction.equals("desc")) {
			return Sort.Direction.DESC;
		}
		return Sort.Direction.ASC;
	}

	@Override
	public DTO saveEmployee(ResultDTO dto) {
		Employee emp1 = empService.dtoToEntity(dto);
		 emp1 = empRepository.save(emp1);
		 ResultDTO res = empService.entityToDto(emp1);
		 DTO empDTO = new DTO();
		 empDTO.setCode("Emp001");
		 empDTO.setMessage("Employee Successfully Created");
		 empDTO.setData(res);
		 return empDTO;
	}
	@Override
	public DTO fetchEmployeeById(Long id) {
		Employee orElse = empRepository.findById(id).orElse(null);
		ResultDTO res = empService.entityToDto(orElse);
		DTO empDTO = new DTO();
		empDTO.setCode("Emp002");
		empDTO.setMessage("Successfully fetched by Id");
		empDTO.setData(res);
		return empDTO;
	}
	
	@Override
	public DTO updateEmployee(Long id, Employee emp1) {
		Employee emp = empService.updateDepartmentById(id,emp1);
		
		 emp=empRepository.findById(id).get();
		if(Objects.nonNull(emp.getFirstName()) &&
				!"".equalsIgnoreCase(emp.getFirstName())){
			emp1.setFirstName(emp.getFirstName());
		}
		if(Objects.nonNull(emp.getLastName()) &&
				!"".equalsIgnoreCase(emp.getLastName())){
			emp1.setLastName(emp.getLastName());
		}
		if(Objects.nonNull(emp.getEmpcode()) &&
				!"".equalsIgnoreCase(emp.getEmpcode())){
			emp1.setEmpcode(emp.getEmpcode());
		}
		if(Objects.nonNull(emp.getDesignation()) &&
				!"".equalsIgnoreCase(emp.getDesignation())){
			emp1.setDesignation(emp.getDesignation());
		}
		if(Objects.nonNull(emp.getEmailId()) &&
				!"".equalsIgnoreCase(emp.getEmailId())){
			emp1.setEmailId(emp.getEmailId());
		}
		if(Objects.nonNull(emp.getDob()) &&
				!"".equalsIgnoreCase(emp.getDob())){
			emp1.setDob(emp.getDob());
		}
		if(Objects.nonNull(emp.getMobile()) &&
				!"".equalsIgnoreCase(emp.getMobile())){
			emp1.setMobile(emp.getMobile());
		}
			Employee emp2  =	empRepository.save(emp1);
			ResultDTO res = empService.entityToDto(emp2);
			DTO empDTO = new DTO();
			empDTO.setCode("Emp003");
			empDTO.setMessage("Successfully updated by Id");
			empDTO.setData(res);
			return empDTO;
	}
	
	
	

}