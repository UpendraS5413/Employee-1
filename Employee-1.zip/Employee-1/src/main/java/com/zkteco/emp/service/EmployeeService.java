package com.zkteco.emp.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import com.zkteco.emp.dto.DTO;
import com.zkteco.emp.dto.ResultDTO;
import com.zkteco.emp.entity.Employee;
import com.zkteco.emp.error.EmployeeNotFoundException;

public interface EmployeeService {
	
	public ResultDTO entityToDto(Employee emp);
	public List<ResultDTO> entityToDto(List<Employee> emp);
	public Employee dtoToEntity(ResultDTO dto);
	public List<Employee> dtoToEntity(List<ResultDTO> dto);
	public Employee updateDepartmentById(Long id, Employee emp);
	public  Employee deleteEmployeeById(Long id) throws EmployeeNotFoundException;
	Page<Employee> findPaginated(int pageNo ,int pageSize);
	public ResponseEntity<Map<String,Object>> getAllEmployee(String search, int page, int size, String[] sort);
	public DTO saveEmployee(ResultDTO dto);
	public DTO fetchEmployeeById(Long id);
	public DTO updateEmployee(Long id, Employee emp);

}
