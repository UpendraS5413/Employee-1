package com.zkteco.emp.entity;

import java.util.Date;

import javax.persistence.*;

import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name="Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long empId;
	@Column(name = "first_name")
	private String firstName;
	@Column(name = "last_name")
	private String lastName;
	@Column(name = "code" )
	private String empcode;
	@Column(name = "designation")
	private String designation;
	@Column(name = "emailId")
	private String emailId;
	@Column(name = "dob")
	private String dob;
	@Column(name = "mobile")
	private String mobile;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date createDate = new Date();
	@Temporal(TemporalType.TIMESTAMP)
	private Date updateDate = new Date();
	
}
