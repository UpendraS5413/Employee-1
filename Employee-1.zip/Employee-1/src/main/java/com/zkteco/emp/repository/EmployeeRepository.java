package com.zkteco.emp.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.zkteco.emp.dto.ResultDTO;
import com.zkteco.emp.entity.Employee;
import com.zkteco.emp.error.EmployeeNotFoundException;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>{

	@Query(value="Select t from Employee t where t.firstName like ?1")
	List<ResultDTO> fetchEmployeeBy(String search)throws EmployeeNotFoundException;

	@Query(value="Select t from Employee t where t.firstName like ?1 OR t.mobile like ?1 OR t.lastName like ?1 OR t.empcode like ?1 OR t.emailId like ?1 OR t.designation like ?1")
	List<Employee> getByName(String value)throws EmployeeNotFoundException;

	@Query(value="delete from Employee t where t.empId=:empId")
	public Employee deleteEmployeeById(Long id)throws EmployeeNotFoundException;
	@Query(value="Select t from Employee t where t.firstName like ?1 OR t.mobile like ?1 OR t.lastName like ?1 OR t.empcode like ?1 OR t.emailId like ?1 OR t.designation like ?1")
	Page<Employee> employeeContaining(String search, Pageable paging);

}
