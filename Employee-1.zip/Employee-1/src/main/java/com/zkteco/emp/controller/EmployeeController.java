package com.zkteco.emp.controller;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.emp.dto.DTO;
import com.zkteco.emp.dto.ResultDTO;
import com.zkteco.emp.entity.Employee;
import com.zkteco.emp.error.EmployeeNotFoundException;
import com.zkteco.emp.repository.EmployeeRepository;
import com.zkteco.emp.service.EmployeeService;

@EnableAutoConfiguration
@RestController
@RequestMapping("/api/v1/employee")
public class EmployeeController {
	@Autowired(required = true)
	EmployeeRepository empRepository;

	@Autowired
	private EmployeeService empService;
	
	@GetMapping("/page/{pageNo}")
	public ResponseEntity<Map<String,Object>> findPaginated(@RequestParam(required = false)String search,
										@RequestParam(defaultValue="0")int page ,
										@RequestParam(defaultValue = "5")int size,
										@RequestParam(defaultValue = "empId,asc") String[] sort) {
		ResponseEntity<Map<String,Object>> res = empService.getAllEmployee(search,page,size,sort);
		return res;	
	}
	
	@GetMapping("/{id}")
	public DTO fetchEmployeeById(@PathVariable(value="id" )Long id) {
			return empService.fetchEmployeeById(id);
	}
	
	@PostMapping
	public DTO saveEmployee(@RequestBody ResultDTO dto) {
		return empService.saveEmployee(dto);
	}

	@PutMapping("/{id}")
	public DTO updateEmployee(@PathVariable(value="id")Long id ,@RequestBody Employee emp) {
		return empService.updateEmployee(id,emp);
	}
	
	@DeleteMapping("/{id}")
	public ResultDTO deleteEmployeeById(@RequestParam(value = "empId")  Long id) throws EmployeeNotFoundException {
		Employee emp=empService.deleteEmployeeById(id);
		return empService.entityToDto(emp);
	}
	
}
